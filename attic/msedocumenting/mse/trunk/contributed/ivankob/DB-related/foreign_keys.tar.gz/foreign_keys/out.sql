create or replace function check_foreign_key() returns "trigger" as '$libdir/refint','check_foreign_key' language c;
create or replace function check_primary_key() returns "trigger" as '$libdir/refint','check_primary_key' language c;

drop trigger if exists trg_data_retail_office_code2ref_offices on data_retail;
create trigger trg_data_retail_office_code2ref_offices before insert or update on data_retail for each row execute procedure check_primary_key('office_code','ref_offices','office_code');
drop trigger if exists trg_ref_offices2data_retail_office_code on ref_offices;
create trigger trg_ref_offices2data_retail_office_code before delete or update on ref_offices for each row execute procedure check_foreign_key('1','restrict','office_code','data_retail','office_code');

drop trigger if exists trg_data_retail_index_code2ref_pasports on data_retail;
create trigger trg_data_retail_index_code2ref_pasports before insert or update on data_retail for each row execute procedure check_primary_key('index_code','ref_pasports','index_code');
drop trigger if exists trg_ref_pasports2data_retail_index_code on ref_pasports;
create trigger trg_ref_pasports2data_retail_index_code before delete or update on ref_pasports for each row execute procedure check_foreign_key('1','restrict','index_code','data_retail','index_code');

drop trigger if exists trg_data_retail_sys_day_window_id2sys_day_window on data_retail;
create trigger trg_data_retail_sys_day_window_id2sys_day_window before insert or update on data_retail for each row execute procedure check_primary_key('sys_day_window_id','sys_day_window','id');
drop trigger if exists trg_sys_day_window2data_retail_sys_day_window_id on sys_day_window;
create trigger trg_sys_day_window2data_retail_sys_day_window_id before delete or update on sys_day_window for each row execute procedure check_foreign_key('1','restrict','id','data_retail','sys_day_window_id');

drop trigger if exists trg_data_ss_index_code2ref_pasports on data_ss;
create trigger trg_data_ss_index_code2ref_pasports before insert or update on data_ss for each row execute procedure check_primary_key('index_code','ref_pasports','index_code');
drop trigger if exists trg_ref_pasports2data_ss_index_code on ref_pasports;
create trigger trg_ref_pasports2data_ss_index_code before delete or update on ref_pasports for each row execute procedure check_foreign_key('1','restrict','index_code','data_ss','index_code');

drop trigger if exists trg_data_ss_office_code2ref_offices on data_ss;
create trigger trg_data_ss_office_code2ref_offices before insert or update on data_ss for each row execute procedure check_primary_key('office_code','ref_offices','office_code');
drop trigger if exists trg_ref_offices2data_ss_office_code on ref_offices;
create trigger trg_ref_offices2data_ss_office_code before delete or update on ref_offices for each row execute procedure check_foreign_key('1','restrict','office_code','data_ss','office_code');

drop trigger if exists trg_data_ss_sys_day_window_id2sys_day_window on data_ss;
create trigger trg_data_ss_sys_day_window_id2sys_day_window before insert or update on data_ss for each row execute procedure check_primary_key('sys_day_window_id','sys_day_window','id');
drop trigger if exists trg_sys_day_window2data_ss_sys_day_window_id on sys_day_window;
create trigger trg_sys_day_window2data_ss_sys_day_window_id before delete or update on sys_day_window for each row execute procedure check_foreign_key('1','restrict','id','data_ss','sys_day_window_id');

drop trigger if exists trg_pasport4window_window_code2ref_windows on pasport4window;
create trigger trg_pasport4window_window_code2ref_windows before insert or update on pasport4window for each row execute procedure check_primary_key('window_code','ref_windows','window_code');
drop trigger if exists trg_ref_windows2pasport4window_window_code on ref_windows;
create trigger trg_ref_windows2pasport4window_window_code before delete or update on ref_windows for each row execute procedure check_foreign_key('1','restrict','window_code','pasport4window','window_code');

drop trigger if exists trg_pasport4window_index_code2ref_pasports on pasport4window;
create trigger trg_pasport4window_index_code2ref_pasports before insert or update on pasport4window for each row execute procedure check_primary_key('index_code','ref_pasports','index_code');
drop trigger if exists trg_ref_pasports2pasport4window_index_code on ref_pasports;
create trigger trg_ref_pasports2pasport4window_index_code before delete or update on ref_pasports for each row execute procedure check_foreign_key('1','restrict','index_code','pasport4window','index_code');

drop trigger if exists trg_ref_aux_indexes_aux_index_code2ref_pasports on ref_aux_indexes;
create trigger trg_ref_aux_indexes_aux_index_code2ref_pasports before insert or update on ref_aux_indexes for each row execute procedure check_primary_key('aux_index_code','ref_pasports','index_code');
drop trigger if exists trg_ref_pasports2ref_aux_indexes_aux_index_code on ref_pasports;
create trigger trg_ref_pasports2ref_aux_indexes_aux_index_code before delete or update on ref_pasports for each row execute procedure check_foreign_key('1','restrict','index_code','ref_aux_indexes','aux_index_code');

drop trigger if exists trg_ref_aux_indexes_main_index_code2ref_pasports on ref_aux_indexes;
create trigger trg_ref_aux_indexes_main_index_code2ref_pasports before insert or update on ref_aux_indexes for each row execute procedure check_primary_key('main_index_code','ref_pasports','index_code');
drop trigger if exists trg_ref_pasports2ref_aux_indexes_main_index_code on ref_pasports;
create trigger trg_ref_pasports2ref_aux_indexes_main_index_code before delete or update on ref_pasports for each row execute procedure check_foreign_key('1','restrict','index_code','ref_aux_indexes','main_index_code');

drop trigger if exists trg_ref_aux_indexes_oper_input2ref_operators on ref_aux_indexes;
create trigger trg_ref_aux_indexes_oper_input2ref_operators before insert or update on ref_aux_indexes for each row execute procedure check_primary_key('oper_input','ref_operators','oper_code');
drop trigger if exists trg_ref_operators2ref_aux_indexes_oper_input on ref_operators;
create trigger trg_ref_operators2ref_aux_indexes_oper_input before delete or update on ref_operators for each row execute procedure check_foreign_key('1','restrict','oper_code','ref_aux_indexes','oper_input');

drop trigger if exists trg_ref_companies_oper_input2ref_operators on ref_companies;
create trigger trg_ref_companies_oper_input2ref_operators before insert or update on ref_companies for each row execute procedure check_primary_key('oper_input','ref_operators','oper_code');
drop trigger if exists trg_ref_operators2ref_companies_oper_input on ref_operators;
create trigger trg_ref_operators2ref_companies_oper_input before delete or update on ref_operators for each row execute procedure check_foreign_key('1','restrict','oper_code','ref_companies','oper_input');

drop trigger if exists trg_ref_nodes_oper_input2ref_operators on ref_nodes;
create trigger trg_ref_nodes_oper_input2ref_operators before insert or update on ref_nodes for each row execute procedure check_primary_key('oper_input','ref_operators','oper_code');
drop trigger if exists trg_ref_operators2ref_nodes_oper_input on ref_operators;
create trigger trg_ref_operators2ref_nodes_oper_input before delete or update on ref_operators for each row execute procedure check_foreign_key('1','restrict','oper_code','ref_nodes','oper_input');

drop trigger if exists trg_ref_offices_oper_input2ref_operators on ref_offices;
create trigger trg_ref_offices_oper_input2ref_operators before insert or update on ref_offices for each row execute procedure check_primary_key('oper_input','ref_operators','oper_code');
drop trigger if exists trg_ref_operators2ref_offices_oper_input on ref_operators;
create trigger trg_ref_operators2ref_offices_oper_input before delete or update on ref_operators for each row execute procedure check_foreign_key('1','restrict','oper_code','ref_offices','oper_input');

drop trigger if exists trg_ref_offices_node_code2ref_nodes on ref_offices;
create trigger trg_ref_offices_node_code2ref_nodes before insert or update on ref_offices for each row execute procedure check_primary_key('node_code','ref_nodes','node_code');
drop trigger if exists trg_ref_nodes2ref_offices_node_code on ref_nodes;
create trigger trg_ref_nodes2ref_offices_node_code before delete or update on ref_nodes for each row execute procedure check_foreign_key('1','restrict','node_code','ref_offices','node_code');

drop trigger if exists trg_ref_operators_office_code2ref_offices on ref_operators;
create trigger trg_ref_operators_office_code2ref_offices before insert or update on ref_operators for each row execute procedure check_primary_key('office_code','ref_offices','office_code');
drop trigger if exists trg_ref_offices2ref_operators_office_code on ref_offices;
create trigger trg_ref_offices2ref_operators_office_code before delete or update on ref_offices for each row execute procedure check_foreign_key('1','restrict','office_code','ref_operators','office_code');

drop trigger if exists trg_ref_operators_role_code2sys_role on ref_operators;
create trigger trg_ref_operators_role_code2sys_role before insert or update on ref_operators for each row execute procedure check_primary_key('role_code','sys_role','role_code');
drop trigger if exists trg_sys_role2ref_operators_role_code on sys_role;
create trigger trg_sys_role2ref_operators_role_code before delete or update on sys_role for each row execute procedure check_foreign_key('1','restrict','role_code','ref_operators','role_code');

drop trigger if exists trg_ref_operators_oper_input2ref_operators on ref_operators;
create trigger trg_ref_operators_oper_input2ref_operators before insert or update on ref_operators for each row execute procedure check_primary_key('oper_input','ref_operators','oper_code');
drop trigger if exists trg_ref_operators2ref_operators_oper_input on ref_operators;
create trigger trg_ref_operators2ref_operators_oper_input before delete or update on ref_operators for each row execute procedure check_foreign_key('1','restrict','oper_code','ref_operators','oper_input');

drop trigger if exists trg_ref_pasports_company_code2ref_companies on ref_pasports;
create trigger trg_ref_pasports_company_code2ref_companies before insert or update on ref_pasports for each row execute procedure check_primary_key('company_code','ref_companies','company_code');
drop trigger if exists trg_ref_companies2ref_pasports_company_code on ref_companies;
create trigger trg_ref_companies2ref_pasports_company_code before delete or update on ref_companies for each row execute procedure check_foreign_key('1','restrict','company_code','ref_pasports','company_code');

drop trigger if exists trg_ref_pasports_oper_input2ref_operators on ref_pasports;
create trigger trg_ref_pasports_oper_input2ref_operators before insert or update on ref_pasports for each row execute procedure check_primary_key('oper_input','ref_operators','oper_code');
drop trigger if exists trg_ref_operators2ref_pasports_oper_input on ref_operators;
create trigger trg_ref_operators2ref_pasports_oper_input before delete or update on ref_operators for each row execute procedure check_foreign_key('1','restrict','oper_code','ref_pasports','oper_input');

drop trigger if exists trg_ref_windows_oper_input2ref_operators on ref_windows;
create trigger trg_ref_windows_oper_input2ref_operators before insert or update on ref_windows for each row execute procedure check_primary_key('oper_input','ref_operators','oper_code');
drop trigger if exists trg_ref_operators2ref_windows_oper_input on ref_operators;
create trigger trg_ref_operators2ref_windows_oper_input before delete or update on ref_operators for each row execute procedure check_foreign_key('1','restrict','oper_code','ref_windows','oper_input');

drop trigger if exists trg_ref_windows_office_code2ref_offices on ref_windows;
create trigger trg_ref_windows_office_code2ref_offices before insert or update on ref_windows for each row execute procedure check_primary_key('office_code','ref_offices','office_code');
drop trigger if exists trg_ref_offices2ref_windows_office_code on ref_offices;
create trigger trg_ref_offices2ref_windows_office_code before delete or update on ref_offices for each row execute procedure check_foreign_key('1','restrict','office_code','ref_windows','office_code');

drop trigger if exists trg_sys_day_window_login_oper_code2ref_operators on sys_day_window;
create trigger trg_sys_day_window_login_oper_code2ref_operators before insert or update on sys_day_window for each row execute procedure check_primary_key('login_oper_code','ref_operators','oper_code');
drop trigger if exists trg_ref_operators2sys_day_window_login_oper_code on ref_operators;
create trigger trg_ref_operators2sys_day_window_login_oper_code before delete or update on ref_operators for each row execute procedure check_foreign_key('1','restrict','oper_code','sys_day_window','login_oper_code');

drop trigger if exists trg_sys_day_window_window_code2ref_windows on sys_day_window;
create trigger trg_sys_day_window_window_code2ref_windows before insert or update on sys_day_window for each row execute procedure check_primary_key('window_code','ref_windows','window_code');
drop trigger if exists trg_ref_windows2sys_day_window_window_code on ref_windows;
create trigger trg_ref_windows2sys_day_window_window_code before delete or update on ref_windows for each row execute procedure check_foreign_key('1','restrict','window_code','sys_day_window','window_code');

drop trigger if exists trg_sys_day_window_exit_oper_code2ref_operators on sys_day_window;
create trigger trg_sys_day_window_exit_oper_code2ref_operators before insert or update on sys_day_window for each row execute procedure check_primary_key('exit_oper_code','ref_operators','oper_code');
drop trigger if exists trg_ref_operators2sys_day_window_exit_oper_code on ref_operators;
create trigger trg_ref_operators2sys_day_window_exit_oper_code before delete or update on ref_operators for each row execute procedure check_foreign_key('1','restrict','oper_code','sys_day_window','exit_oper_code');

drop trigger if exists trg_sys_day_oper_code2ref_operators on sys_day;
create trigger trg_sys_day_oper_code2ref_operators before insert or update on sys_day for each row execute procedure check_primary_key('oper_code','ref_operators','oper_code');
drop trigger if exists trg_ref_operators2sys_day_oper_code on ref_operators;
create trigger trg_ref_operators2sys_day_oper_code before delete or update on ref_operators for each row execute procedure check_foreign_key('1','restrict','oper_code','sys_day','oper_code');

