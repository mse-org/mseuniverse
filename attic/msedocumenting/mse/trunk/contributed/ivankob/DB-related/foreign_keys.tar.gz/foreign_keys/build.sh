#!/bin/sh

CD=`pwd`
IMPS=`find $CD -ilname '*'`

echo -e "create or replace function check_foreign_key() returns \"trigger\"\
 as '\$libdir/refint','check_foreign_key' language c;" > ./out.sql

echo -e "create or replace function check_primary_key() returns \"trigger\"\
 as '\$libdir/refint','check_primary_key' language c;\n" >> ./out.sql

for imp in $IMPS; do
    REF=`echo $imp | awk -v v1="${CD}/" '{gsub(v1,"",$NF);print $NF}'`
    DEREF=`ls -l ${imp} | awk -v v1="${CD}/" '{gsub(v1,"",$NF);print $NF}'`
    echo 1 | awk -v v1=$REF -v v2=$DEREF '{
	split(v1,A1,"/");
	split(v2,A2,"/");
	TR1="trg_"A1[1]"_"A1[3]"2"A2[1];
	TR2="trg_"A2[1]"2"A1[1]"_"A1[3];
	print "drop trigger if exists "TR1" on "A1[1]";\n"\
	      "create trigger "TR1" before insert or update on "A1[1]\
	      " for each row execute procedure check_primary_key(#"A1[3]"#,#"A2[1]"#,#"A2[3]"#);\n"\
	      "drop trigger if exists "TR2" on "A2[1]";\n"\
	      "create trigger "TR2" before delete or update on "A2[1]\
	      " for each row execute procedure check_foreign_key(#1#,#restrict#,#"A2[3]"#,#"A1[1]"#,#"A1[3]"#);\n"
    }'
done | tr "#" "'" >> ./out.sql
